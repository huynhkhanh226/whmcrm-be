module.exports = {


  friendlyName: 'Token',


  description: 'Token something.',


  inputs: {

  },


  exits: {

    success: {
      description: 'All done.',
    },

  },


  fn: async function (inputs) {
    // TODO
  }


};

