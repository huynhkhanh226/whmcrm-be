module.exports = {


  friendlyName: 'Hello',


  description: 'Hello home.',


  inputs: {

  },


  exits: {

  },


  fn: async function (inputs) {

    // All done.
    return "Hello VNDEVHOST Back-End";

  }


};
