
module.exports.mail = {

  mailServer: "smtp.gmail.com",
  sender: "huynhkhanh226@gmail.com",
  username: "huynhkhanh226@gmail.com",
  password: "Khanh@123456",
  secure: true,
  port: 465 //TLS 587
  
};
