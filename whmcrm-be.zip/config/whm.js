
module.exports.whm = {
  acc: "vndehvla",
  token: "FHLPSIJTSQ0ZWZEFYFGTAQ1ZQMG17N67",
  base: "https://host75.registrar-servers.com:2087",
  version: "?api.version=1",
};
