define({
  "title": "Custom apiDoc browser title",
  "url": "https://api.github.com/v1",
  "name": "example",
  "version": "0.1.0",
  "description": "apiDoc basic example",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-07-19T12:38:08.734Z",
    "url": "http://apidocjs.com",
    "version": "0.23.0"
  }
});
